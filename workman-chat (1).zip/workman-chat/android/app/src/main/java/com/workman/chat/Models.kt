package com.workman.chat

import org.json.JSONObject

/** One chat message. [id] is a random UUID, used everywhere to drop duplicates. */
data class Msg(
    val id: String,
    val sid: String,      // sender device id
    val name: String,     // sender display name
    val text: String,
    val ts: Long,         // sent time (ms)
    val sent: Boolean = true   // false = still waiting for a link (only meaningful for my own messages)
) {
    /** What travels over Nearby / internet (always encrypted before it leaves the phone). */
    fun toWire(): String = JSONObject()
        .put("i", id).put("s", sid).put("n", name).put("t", text).put("ts", ts)
        .toString()

    /** What is saved on this phone. */
    fun toStore(): JSONObject = JSONObject(toWire()).put("x", sent)

    companion object {
        fun fromWire(s: String, sentDefault: Boolean = true): Msg? = try {
            val o = JSONObject(s)
            val text = o.getString("t")
            if (text.length > 4000) null
            else Msg(
                id = o.getString("i"),
                sid = o.getString("s"),
                name = o.optString("n", "?").take(40),
                text = text,
                ts = o.getLong("ts"),
                sent = o.optBoolean("x", sentDefault)
            )
        } catch (e: Exception) {
            null
        }
    }
}

enum class CloudState { NOT_SET, CONNECTING, ONLINE, OFFLINE }
