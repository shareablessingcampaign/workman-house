package com.workman.chat

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B141B)
private val Panel = Color(0xFF152129)
private val Green = Color(0xFF2ED573)
private val Mine = Color(0xFF0F5D3F)
private val Amber = Color(0xFFFFB020)
private val Grey = Color(0xFF8696A0)

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private lateinit var store: ChatStore
    private lateinit var engine: ChatEngine

    private var permsOk by mutableStateOf(false)
    private var configured by mutableStateOf(false)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            permsOk = hasPerms()
            if (configured) engine.start(permsOk)
        }

    /** Runtime permissions Nearby Connections needs on this Android version. */
    private fun requiredPerms(): List<String> {
        val l = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
            l.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT <= 32) l.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        return l
    }

    private fun hasPerms() = requiredPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        store = ChatStore(prefs)
        engine = ChatEngine(applicationContext, prefs, store)
        configured = prefs.configured
        permsOk = hasPerms()

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Green, onPrimary = Color.Black,
                    background = Bg, surface = Bg, onSurface = Color.White,
                    onBackground = Color.White
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    AppRoot()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        permsOk = hasPerms()
        if (configured) engine.start(permsOk)
    }

    override fun onStop() {
        engine.stop()
        super.onStop()
    }

    private fun askPerms() {
        permLauncher.launch(requiredPerms().toTypedArray())
    }

    private fun saveSettings(name: String, room: String, url: String) {
        val roomChanged = room.trim().lowercase() != prefs.room.trim().lowercase()
        prefs.name = name
        prefs.room = room
        prefs.dbUrl = url
        if (roomChanged) store.clear()
        configured = prefs.configured
        if (!permsOk) askPerms()
        engine.start(permsOk)
    }

    @Composable
    private fun AppRoot() {
        var splash by remember { mutableStateOf(true) }
        var settings by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            delay(1400)
            splash = false
        }
        when {
            splash -> SplashScreen()
            !configured || settings -> SetupScreen(
                canCancel = configured,
                onCancel = { settings = false },
                onSave = { n, r, u ->
                    saveSettings(n, r, u)
                    settings = false
                }
            )
            else -> ChatScreen(onSettings = { settings = true })
        }
    }

    @Composable
    private fun SplashScreen() {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.logo),
                    contentDescription = "Workman Chat",
                    modifier = Modifier.size(150.dp).clip(RoundedCornerShape(34.dp)),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.height(20.dp))
                Text("Workman Chat", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Nearby or online. Always connected.", fontSize = 14.sp, color = Grey)
            }
        }
    }

    @Composable
    private fun SetupScreen(
        canCancel: Boolean,
        onCancel: () -> Unit,
        onSave: (String, String, String) -> Unit
    ) {
        var name by remember { mutableStateOf(prefs.name) }
        var room by remember { mutableStateOf(prefs.room) }
        var url by remember { mutableStateOf(prefs.dbUrl) }
        var showErr by remember { mutableStateOf(false) }
        val valid = name.isNotBlank() && room.trim().length >= 4

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(84.dp).clip(RoundedCornerShape(20.dp))
            )
            Spacer(Modifier.height(12.dp))
            Text("Set up your chat", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Your name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = room, onValueChange = { room = it },
                label = { Text("Secret room code (same on every phone)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Phones with the same code chat together, nearby or online. " +
                    "The code also locks (encrypts) every message. Use at least 4 characters.",
                fontSize = 12.sp, color = Grey, modifier = Modifier.padding(top = 4.dp)
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = url, onValueChange = { url = it },
                label = { Text("Internet database URL (optional)") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Leave empty to use Nearby only. To also chat over the internet, paste your " +
                    "Firebase Realtime Database URL (see README).",
                fontSize = 12.sp, color = Grey, modifier = Modifier.padding(top = 4.dp)
            )
            if (showErr && !valid) {
                Text(
                    "Please enter your name and a room code of at least 4 characters.",
                    color = Amber, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)
                )
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (valid) onSave(name, room, url) else showErr = true
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save and start") }
            if (canCancel) {
                TextButton(onClick = onCancel) { Text("Cancel", color = Grey) }
            }
        }
    }

    @Composable
    private fun Chip(label: String, value: String, color: Color) {
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Panel).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(6.dp))
            Text("$label: $value", fontSize = 12.sp, color = Color.White)
        }
    }

    @Composable
    private fun ChatScreen(onSettings: () -> Unit) {
        val myId = prefs.deviceId
        var draft by remember { mutableStateOf("") }
        val listState = rememberLazyListState()
        val msgs = store.messages

        LaunchedEffect(msgs.size) {
            if (msgs.isNotEmpty()) listState.scrollToItem(msgs.size - 1)
        }

        val nearbyColor = when {
            engine.peers > 0 -> Green
            permsOk -> Amber
            else -> Grey
        }
        val cloudColor = when (engine.cloudState) {
            CloudState.ONLINE -> Green
            CloudState.CONNECTING -> Amber
            CloudState.OFFLINE -> Amber
            CloudState.NOT_SET -> Grey
        }
        val cloudText = when (engine.cloudState) {
            CloudState.ONLINE -> "Online"
            CloudState.CONNECTING -> "Connecting…"
            CloudState.OFFLINE -> engine.cloudInfo ?: "Offline"
            CloudState.NOT_SET -> "Not set up"
        }

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
        ) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(R.drawable.logo),
                    contentDescription = null,
                    modifier = Modifier.size(38.dp).clip(RoundedCornerShape(9.dp))
                )
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Workman Chat", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(prefs.name, fontSize = 12.sp, color = Grey)
                }
                TextButton(onClick = onSettings) { Text("Settings", color = Green) }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip("Nearby", engine.nearbyText, nearbyColor)
                Chip("Internet", cloudText, cloudColor)
            }

            if (!permsOk) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(12.dp))
                        .background(Panel).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Allow Nearby permissions so phones can find each other without internet.",
                        fontSize = 13.sp, modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { askPerms() }) { Text("Allow") }
                }
            }

            val pending = store.pendingCount
            if (pending > 0) {
                Text(
                    "$pending message" + (if (pending > 1) "s" else "") +
                        " waiting. They send when a nearby phone or the internet is available.",
                    fontSize = 12.sp, color = Amber,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(msgs, key = { it.id }) { m -> Bubble(m, m.sid == myId) }
            }

            Row(
                Modifier.fillMaxWidth().padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it },
                    placeholder = { Text("Message", color = Grey) },
                    modifier = Modifier.weight(1f), maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (draft.isNotBlank()) {
                        engine.send(draft)
                        draft = ""
                    }
                }) { Text("Send") }
            }
        }
    }

    @Composable
    private fun Bubble(m: Msg, mine: Boolean) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
        ) {
            Column(
                Modifier.widthIn(max = 290.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (mine) Mine else Panel)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                if (!mine) Text(m.name, fontSize = 12.sp, color = Green, fontWeight = FontWeight.Bold)
                Text(m.text, fontSize = 16.sp)
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.ts))
                Text(
                    if (mine) time + (if (m.sent) "  ✓" else "  waiting…") else time,
                    fontSize = 10.sp, color = Grey,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}
