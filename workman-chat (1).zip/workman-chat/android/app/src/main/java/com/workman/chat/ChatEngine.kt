package com.workman.chat

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale
import java.util.UUID
import javax.crypto.spec.SecretKeySpec

/**
 * Decides how every message travels:
 *   1. Nearby phones (Bluetooth / Wi-Fi Direct, no data)   2. Internet (Firebase)
 * It uses both when both are available, queues the message when neither is, and
 * relays messages for others (a phone with internet becomes a gateway for phones without).
 * Everything here runs on the main thread.
 */
class ChatEngine(
    private val appCtx: Context,
    private val prefs: Prefs,
    val store: ChatStore
) {
    var peers by mutableIntStateOf(0)
    var nearbyText by mutableStateOf("Off")
    var cloudState by mutableStateOf(CloudState.NOT_SET)
    var cloudInfo by mutableStateOf<String?>(null)

    private val main = Handler(Looper.getMainLooper())
    private var key: SecretKeySpec? = null
    private var nearby: NearbyLink? = null
    private var cloud: CloudLink? = null
    private var generation = 0

    fun start(nearbyAllowed: Boolean) {
        stop()
        if (!prefs.configured) return
        val gen = ++generation
        val code = prefs.room
        key = Crypto.key(code)
        val roomId = Crypto.roomId(code)

        if (nearbyAllowed) {
            nearbyText = "Searching…"
            nearby = NearbyLink(appCtx, prefs.deviceId, prefs.name, roomId, object : NearbyLink.Callback {
                override fun onPeers(count: Int) {
                    peers = count
                    nearbyText = if (count > 0) "$count phone" + (if (count > 1) "s" else "") else "Searching…"
                }

                override fun onBytes(fromEndpoint: String, data: ByteArray) = receive(data, fromEndpoint)

                override fun onPeerConnected(endpoint: String) {
                    // give the new phone our recent history, then push anything still waiting
                    val k = key ?: return
                    store.recent(50).forEach { nearby?.sendTo(endpoint, Crypto.encrypt(k, it.toWire())) }
                    flushPending()
                }

                override fun onError(message: String) {
                    nearbyText = message
                }
            }).also { it.start() }
        } else {
            nearbyText = "Needs permission"
        }

        if (prefs.dbUrl.isNotBlank()) {
            cloudState = CloudState.CONNECTING
            cloud = CloudLink(prefs.dbUrl, roomId, object : CloudLink.Callback {
                override fun onState(online: Boolean, info: String?) {
                    main.post {
                        if (gen != generation) return@post
                        cloudState = if (online) CloudState.ONLINE else CloudState.OFFLINE
                        cloudInfo = info
                        if (online) {
                            uploadRecent()
                            flushPending()
                        }
                    }
                }

                override fun onCipher(base64: String) {
                    val bytes = try { Base64.decode(base64, Base64.NO_WRAP) } catch (e: Exception) { return }
                    main.post { if (gen == generation) receive(bytes, null) }
                }
            }).also { it.start() }
        } else {
            cloudState = CloudState.NOT_SET
        }
    }

    fun stop() {
        generation++
        nearby?.stop(); nearby = null
        cloud?.stop(); cloud = null
        key = null
        peers = 0
        nearbyText = "Off"
        cloudState = if (prefs.dbUrl.isBlank()) CloudState.NOT_SET else CloudState.OFFLINE
    }

    fun send(text: String) {
        val t = text.trim().take(2000)
        if (t.isEmpty()) return
        val m = Msg(UUID.randomUUID().toString(), prefs.deviceId, prefs.name, t, System.currentTimeMillis(), false)
        store.add(m)
        trySend(m)
    }

    private fun flushPending() {
        store.pendingOf(prefs.deviceId).forEach { trySend(it) }
    }

    private fun cloudKey(m: Msg) = String.format(Locale.US, "%013d_%s", m.ts, m.id.take(8))

    /** Tries every available route. Marks the message sent once at least one route took it. */
    private fun trySend(m: Msg) {
        val k = key ?: return
        val bytes = Crypto.encrypt(k, m.toWire())
        if (nearby?.send(bytes) == true) store.markSent(m.id)
        pushToCloud(m, bytes) { ok -> if (ok) store.markSent(m.id) }
    }

    private fun pushToCloud(m: Msg, bytes: ByteArray, done: ((Boolean) -> Unit)? = null) {
        val c = cloud
        if (c == null || cloudState != CloudState.ONLINE) return
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        c.put(cloudKey(m), b64, m.ts) { ok -> if (done != null) main.post { done(ok) } }
    }

    /** When internet comes back, share what nearby phones told us while we were offline. */
    private fun uploadRecent() {
        val k = key ?: return
        store.recent(30).forEach { pushToCloud(it, Crypto.encrypt(k, it.toWire())) }
    }

    /** A message arrived from a nearby phone ([from] != null) or from the internet (null). */
    private fun receive(data: ByteArray, from: String?) {
        val k = key ?: return
        val plain = Crypto.decrypt(k, data) ?: return
        val m = Msg.fromWire(plain, true) ?: return
        if (!store.add(m)) return                  // already known -> also stops relay loops
        nearby?.send(data, exclude = from)         // pass on to other nearby phones
        if (from != null) pushToCloud(m, data)     // we are a gateway: nearby -> internet
    }

    fun clearHistory() = store.clear()
}
