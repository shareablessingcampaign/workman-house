package com.workman.chat

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Everything sent off the phone is AES-256-GCM encrypted with a key made from the room code. */
object Crypto {
    private val rng = SecureRandom()

    private fun norm(code: String) = code.trim().lowercase()

    /** Public, non-reversible id used as the Firebase folder and the Nearby service name. */
    fun roomId(code: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(("wc-room:" + norm(code)).toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(20)
    }

    fun key(code: String): SecretKeySpec {
        val spec = PBEKeySpec(norm(code).toCharArray(), "workman-chat-v1".toByteArray(), 20000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return SecretKeySpec(f.generateSecret(spec).encoded, "AES")
    }

    fun encrypt(key: SecretKeySpec, plain: String): ByteArray {
        val iv = ByteArray(12).also { rng.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
    }

    /** Returns null if the data is not from this room (wrong key) or was tampered with. */
    fun decrypt(key: SecretKeySpec, data: ByteArray): String? = try {
        if (data.size < 13) null
        else {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(0, 12)))
            String(c.doFinal(data, 12, data.size - 12), Charsets.UTF_8)
        }
    } catch (e: Exception) {
        null
    }
}
