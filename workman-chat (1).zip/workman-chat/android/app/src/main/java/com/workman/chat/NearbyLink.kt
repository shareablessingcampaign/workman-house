package com.workman.chat

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy

/**
 * Phone-to-phone link with NO mobile data and NO Wi-Fi network needed.
 * Google Nearby Connections picks Bluetooth / BLE / Wi-Fi Direct by itself.
 * All callbacks arrive on the main thread.
 */
class NearbyLink(
    ctx: Context,
    private val myId: String,
    myName: String,
    roomId: String,
    private val cb: Callback
) {
    interface Callback {
        fun onPeers(count: Int)
        fun onBytes(fromEndpoint: String, data: ByteArray)
        fun onPeerConnected(endpoint: String)
        fun onError(message: String)
    }

    private val client = Nearby.getConnectionsClient(ctx.applicationContext)
    private val serviceId = "com.workman.chat.$roomId"
    private val advName = myId + "|" + myName.replace("|", " ")
    private val handler = Handler(Looper.getMainLooper())

    private val connected = LinkedHashSet<String>()
    private val requested = HashSet<String>()
    private val found = HashMap<String, String>()   // endpointId -> advertised name
    private var running = false

    private val payloads = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                payload.asBytes()?.let { cb.onBytes(endpointId, it) }
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    private val life = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            // The room code is already part of the service id and every message is encrypted,
            // so we accept automatically.
            client.acceptConnection(endpointId, payloads)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            requested.remove(endpointId)
            if (result.status.isSuccess) {
                connected.add(endpointId)
                cb.onPeers(connected.size)
                cb.onPeerConnected(endpointId)
            } else {
                scheduleRetry(endpointId)
            }
        }

        override fun onDisconnected(endpointId: String) {
            connected.remove(endpointId)
            requested.remove(endpointId)
            cb.onPeers(connected.size)
            scheduleRetry(endpointId)
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            found[endpointId] = info.endpointName
            val peerId = info.endpointName.substringBefore('|')
            if (myId > peerId) {
                tryConnect(endpointId)
            } else {
                // The other phone normally calls us. If it does not within 8 s, call it ourselves.
                handler.postDelayed({
                    if (running && found.containsKey(endpointId)) tryConnect(endpointId)
                }, 8000)
            }
        }

        override fun onEndpointLost(endpointId: String) {
            found.remove(endpointId)
        }
    }

    fun start() {
        running = true
        client.startAdvertising(
            advName, serviceId, life,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { e -> fail("Nearby (advertise)", e) }

        client.startDiscovery(
            serviceId, discovery,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        ).addOnFailureListener { e -> fail("Nearby (search)", e) }
    }

    private fun fail(what: String, e: Exception) {
        val code = (e as? ApiException)?.statusCode
        if (code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING ||
            code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING
        ) return
        cb.onError("$what: ${e.message ?: "failed"}")
    }

    private fun tryConnect(endpointId: String) {
        if (!running || connected.contains(endpointId) || requested.contains(endpointId)) return
        requested.add(endpointId)
        client.requestConnection(advName, endpointId, life)
            .addOnFailureListener { e ->
                requested.remove(endpointId)
                val code = (e as? ApiException)?.statusCode
                if (code != ConnectionsStatusCodes.STATUS_ALREADY_CONNECTED_TO_ENDPOINT) {
                    scheduleRetry(endpointId)
                }
            }
    }

    private fun scheduleRetry(endpointId: String) {
        handler.postDelayed({
            if (running && found.containsKey(endpointId) && !connected.contains(endpointId)) {
                tryConnect(endpointId)
            }
        }, 4000)
    }

    val peerCount: Int get() = connected.size

    /** Sends to every connected phone (except [exclude]). Returns false if nobody is connected. */
    fun send(data: ByteArray, exclude: String? = null): Boolean {
        val targets = connected.filter { it != exclude }
        if (targets.isEmpty()) return false
        client.sendPayload(targets, Payload.fromBytes(data))
        return true
    }

    fun sendTo(endpointId: String, data: ByteArray) {
        if (connected.contains(endpointId)) client.sendPayload(endpointId, Payload.fromBytes(data))
    }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (e: Exception) { /* ignore */ }
        connected.clear()
        requested.clear()
        found.clear()
    }
}
