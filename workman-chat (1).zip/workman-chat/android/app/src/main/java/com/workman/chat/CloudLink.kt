package com.workman.chat

import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Internet link through a Firebase Realtime Database, using plain HTTPS (no Firebase SDK).
 * Messages are stored already encrypted, in /rooms/<roomId>/msgs/<time_id>.
 * Callbacks arrive on BACKGROUND threads.
 */
class CloudLink(dbUrl: String, roomId: String, private val cb: Callback) {
    interface Callback {
        fun onState(online: Boolean, info: String?)
        fun onCipher(base64: String)
    }

    private val base: String = normalize(dbUrl)
    private val msgsPath = "$base/rooms/$roomId/msgs"

    @Volatile private var running = false
    @Volatile private var conn: HttpURLConnection? = null
    private var thread: Thread? = null
    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var backoff = 2000L

    fun start() {
        running = true
        thread = Thread({ loop() }, "workman-cloud").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        try { conn?.disconnect() } catch (e: Exception) { /* ignore */ }
        thread?.interrupt()
        io.shutdown()
    }

    private fun loop() {
        while (running) {
            var info: String? = null
            try {
                stream()
            } catch (e: Exception) {
                if (!running) break
                info = e.message
            }
            if (!running) break
            cb.onState(false, info)
            try { Thread.sleep(backoff) } catch (e: InterruptedException) { break }
            backoff = minOf(backoff * 2, 30000L)
        }
    }

    private fun stream() {
        val url = "$msgsPath.json?orderBy=%22%24key%22&limitToLast=200"
        val c = URL(url).openConnection() as HttpURLConnection
        conn = c
        c.setRequestProperty("Accept", "text/event-stream")
        c.connectTimeout = 15000
        c.readTimeout = 75000
        val code = c.responseCode
        if (code != 200) {
            val hint = if (code == 401 || code == 403) " (check the database rules)" else ""
            c.disconnect()
            throw IOException("HTTP $code$hint")
        }
        backoff = 2000L
        cb.onState(true, null)
        BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { r ->
            var event = ""
            while (running) {
                val line = r.readLine() ?: break
                if (line.startsWith("event:")) {
                    event = line.substring(6).trim()
                } else if (line.startsWith("data:")) {
                    handle(event, line.substring(5).trim())
                }
            }
        }
        c.disconnect()
    }

    private fun handle(event: String, data: String) {
        if (event != "put" && event != "patch") return
        try {
            val o = JSONObject(data)
            val path = o.optString("path", "/")
            val d = o.opt("data")
            if (d !is JSONObject) return
            if (path == "/") {
                val keys = d.keys()
                while (keys.hasNext()) {
                    val v = d.optJSONObject(keys.next()) ?: continue
                    val s = v.optString("d", "")
                    if (s.isNotEmpty()) cb.onCipher(s)
                }
            } else {
                val s = d.optString("d", "")
                if (s.isNotEmpty()) cb.onCipher(s)
            }
        } catch (e: Exception) { /* ignore a bad event */ }
    }

    /** Uploads one encrypted message. [done] gets true on success (called on a background thread). */
    fun put(key: String, base64: String, ts: Long, done: (Boolean) -> Unit) {
        try {
            io.execute {
                var ok = false
                try {
                    val c = URL("$msgsPath/$key.json").openConnection() as HttpURLConnection
                    c.requestMethod = "PUT"
                    c.doOutput = true
                    c.connectTimeout = 15000
                    c.readTimeout = 15000
                    c.setRequestProperty("Content-Type", "application/json")
                    val body = JSONObject().put("d", base64).put("t", ts).toString()
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    ok = c.responseCode in 200..299
                    c.disconnect()
                } catch (e: Exception) { /* stays false */ }
                done(ok)
            }
        } catch (e: Exception) {
            done(false)
        }
    }

    companion object {
        fun normalize(u: String): String {
            var s = u.trim().trimEnd('/')
            if (!s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
            return s
        }
    }
}
