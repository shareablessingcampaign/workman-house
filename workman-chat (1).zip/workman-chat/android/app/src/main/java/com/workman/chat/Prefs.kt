package com.workman.chat

import android.content.Context
import java.util.UUID

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("workman_chat", Context.MODE_PRIVATE)

    val deviceId: String
        get() {
            var v = sp.getString("device_id", null)
            if (v == null) {
                v = UUID.randomUUID().toString().replace("-", "").take(12)
                sp.edit().putString("device_id", v).apply()
            }
            return v!!
        }

    var name: String
        get() = sp.getString("name", "") ?: ""
        set(v) { sp.edit().putString("name", v.trim().take(30)).apply() }

    /** Secret room code. Everyone who types the same code is in the same chat. */
    var room: String
        get() = sp.getString("room", "") ?: ""
        set(v) { sp.edit().putString("room", v.trim()).apply() }

    /** Optional Firebase Realtime Database URL, e.g. https://my-app-default-rtdb.firebaseio.com */
    var dbUrl: String
        get() = sp.getString("db_url", "") ?: ""
        set(v) { sp.edit().putString("db_url", v.trim()).apply() }

    var messages: String
        get() = sp.getString("messages", "[]") ?: "[]"
        set(v) { sp.edit().putString("messages", v).apply() }

    val configured: Boolean get() = name.isNotBlank() && room.trim().length >= 4
}
