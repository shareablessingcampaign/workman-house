package com.workman.chat

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray

/** Message list shown on screen, saved on the phone. Call only from the main thread. */
class ChatStore(private val prefs: Prefs) {
    val messages = mutableStateListOf<Msg>()
    private val ids = HashSet<String>()

    init {
        try {
            val arr = JSONArray(prefs.messages)
            for (i in 0 until arr.length()) {
                val m = Msg.fromWire(arr.getJSONObject(i).toString(), true) ?: continue
                if (ids.add(m.id)) messages.add(m)
            }
        } catch (e: Exception) { /* start empty */ }
    }

    /** True if the message is new (not seen before). */
    fun add(m: Msg): Boolean {
        if (!ids.add(m.id)) return false
        var i = messages.size
        while (i > 0 && messages[i - 1].ts > m.ts) i--
        messages.add(i, m)
        while (messages.size > MAX) {
            ids.remove(messages[0].id)
            messages.removeAt(0)
        }
        save()
        return true
    }

    fun markSent(id: String) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0 && !messages[i].sent) {
            messages[i] = messages[i].copy(sent = true)
            save()
        }
    }

    fun pendingOf(deviceId: String): List<Msg> = messages.filter { !it.sent && it.sid == deviceId }

    val pendingCount: Int get() = messages.count { !it.sent }

    fun recent(n: Int): List<Msg> = messages.takeLast(n)

    fun clear() {
        messages.clear()
        ids.clear()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        messages.forEach { arr.put(it.toStore()) }
        prefs.messages = arr.toString()
    }

    companion object { const val MAX = 300 }
}
