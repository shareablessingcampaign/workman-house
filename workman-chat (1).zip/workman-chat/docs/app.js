'use strict';
/* Workman Chat – web preview.
   NOTE: browsers cannot open a Bluetooth chat link between two phones, so the Bluetooth
   behaviour on this page is a simulation. The real thing is the Android app in /android. */

const $ = (id) => document.getElementById(id);
const STORAGE_KEY = 'workman_chat_messages_v1';
const SETTINGS_KEY = 'workman_chat_settings_v1';
const DEFAULT_NAME = 'Partner';

const PEER_REPLIES = [
  "Okay, I'm in the kitchen! ❤️",
  'Give me 5 minutes, coming now 😊',
  'Can you bring the phone charger?',
  'Got it! Bluetooth is super clear here 👍',
  'Almost done, 10 mins 🍲',
  'Haha yes, no data needed at all 😂'
];

const RANGE = {
  1: { label: 'Same room (~4 m • -54 dBm)', rssi: -54, bars: 4 },
  2: { label: 'Through wall (~14 m • -76 dBm)', rssi: -76, bars: 2 },
  3: { label: 'Out of range (>30 m)', rssi: -98, bars: 0 }
};

const EMOJI = ['❤️', '😂', '🍲', '☕', '👍', '🙏', '🏠', '😘', '😊', '😮', '🔥', '🎉', '✅', '📍', '💧', '👋'];

const state = {
  contactName: DEFAULT_NAME,
  bluetoothOn: true,
  connectedDeviceId: 'dev_partner',
  rangeLevel: 1,
  autoReply: true,
  activeRole: 'me',     // who is typing in the main phone: 'me' | 'peer'
  splitView: false,
  theme: 'light',
  demoBarHidden: false,
  devices: [
    { id: 'dev_partner', name: "Partner's Phone", mac: 'A4:83:E7:29:11:B0', rssi: -54 },
    { id: 'dev_tablet', name: 'Office Tablet', mac: 'BC:92:10:4F:88:C2', rssi: -71 },
    { id: 'dev_speaker', name: 'JBL Speaker', mac: '40:EF:4C:12:99:01', rssi: -82 }
  ],
  messages: []
};

let voiceTimer = null;
let voiceSeconds = 0;
let replying = false;
let deferredInstall = null;

/* ---------- storage ---------- */
function loadJSON(key) {
  try { return JSON.parse(localStorage.getItem(key)); } catch (e) { return null; }
}
function saveJSON(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* storage may be blocked */ }
}
function saveMessages() { saveJSON(STORAGE_KEY, state.messages); }
function saveSettings() {
  saveJSON(SETTINGS_KEY, {
    contactName: state.contactName,
    autoReply: state.autoReply,
    theme: state.theme,
    demoBarHidden: state.demoBarHidden
  });
}

/* ---------- init ---------- */
function init() {
  const s = loadJSON(SETTINGS_KEY);
  if (s) {
    state.contactName = s.contactName || DEFAULT_NAME;
    state.autoReply = s.autoReply !== false;
    state.theme = s.theme || 'light';
    state.demoBarHidden = !!s.demoBarHidden;
  } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    state.theme = 'dark';
  }

  const saved = loadJSON(STORAGE_KEY);
  if (Array.isArray(saved) && saved.length) {
    state.messages = saved;
  } else {
    const now = Date.now();
    state.messages = [
      { id: now - 2, sender: 'peer', text: 'Hi! My data just finished 😅 Can we chat over Bluetooth?', time: fmtTime(new Date(now - 180000)), status: 'read', type: 'text' },
      { id: now - 1, sender: 'me', text: 'Yes! Workman Chat works with zero data 📶', time: fmtTime(new Date(now - 120000)), status: 'read', type: 'text' }
    ];
    saveMessages();
  }

  applyTheme();
  renderName();
  $('autoTag').textContent = state.autoReply ? 'ON' : 'OFF';
  $('demoBar').hidden = state.demoBarHidden;
  buildEmoji();
  renderDevices();
  updateConnectionUI();
  renderMessages();
  setupAppLink();

  // input handling
  const input = $('msgInput');
  input.addEventListener('input', handleInput);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendCurrent(); });
  $('fab').addEventListener('click', () => {
    if (input.value.trim()) sendCurrent(); else startRecording();
  });
  $('msgInput2').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendFrom2(); });

  const nameInput = $('nameInput');
  nameInput.addEventListener('blur', commitName);
  nameInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') commitName(); });

  // overlays: tap outside to close
  document.querySelectorAll('.overlay').forEach((o) => {
    o.addEventListener('click', (e) => { if (e.target === o) o.hidden = true; });
  });
  document.addEventListener('click', (e) => {
    const menu = $('menu');
    if (!menu.hidden && !menu.contains(e.target)) menu.hidden = true;
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      $('menu').hidden = true;
      $('btModal').hidden = true;
      $('appModal').hidden = true;
    }
  });

  // splash
  $('splash').addEventListener('click', hideSplash);
  setTimeout(hideSplash, 1900);

  // PWA
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstall = e;
    $('installBtn').hidden = false;
    $('installBtn2').hidden = false;
  });
  window.addEventListener('appinstalled', () => {
    deferredInstall = null;
    $('installBtn').hidden = true;
    $('installBtn2').hidden = true;
    toast('Workman Chat installed');
  });
}
document.addEventListener('DOMContentLoaded', init);

function hideSplash() {
  const s = $('splash');
  if (!s || s.dataset.done) return;
  s.dataset.done = '1';
  s.classList.add('out');
  setTimeout(() => s.remove(), 600);
}

/* ---------- helpers ---------- */
function fmtTime(d) {
  return (d || new Date()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function escapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 2400);
}
function scrollToBottom() {
  ['chat', 'chat2'].forEach((id) => { const c = $(id); if (c) c.scrollTop = c.scrollHeight; });
}

/* ---------- theme / menu ---------- */
function applyTheme() {
  document.documentElement.classList.toggle('dark', state.theme === 'dark');
  const m = document.querySelector('meta[name=theme-color]');
  if (m) m.setAttribute('content', state.theme === 'dark' ? '#1F2C34' : '#075E54');
}
function toggleTheme() {
  state.theme = state.theme === 'dark' ? 'light' : 'dark';
  applyTheme();
  saveSettings();
}
function toggleMenu(e) {
  e.stopPropagation();
  $('menu').hidden = !$('menu').hidden;
}
function closeMenu() { $('menu').hidden = true; }
function dismissDemoBar() {
  state.demoBarHidden = true;
  $('demoBar').hidden = true;
  saveSettings();
}

/* ---------- contact name ---------- */
function renderName() { $('nameBtn').textContent = state.contactName; }
function editContactName() {
  const input = $('nameInput');
  input.value = state.contactName;
  $('nameBtn').hidden = true;
  input.hidden = false;
  input.focus();
  input.select();
}
function commitName() {
  const input = $('nameInput');
  if (input.hidden) return;
  state.contactName = input.value.trim() || DEFAULT_NAME;
  input.hidden = true;
  $('nameBtn').hidden = false;
  renderName();
  saveSettings();
}

/* ---------- Bluetooth simulation ---------- */
function isConnected() {
  return state.bluetoothOn && state.connectedDeviceId !== null && state.rangeLevel < 3;
}

function setBars(n) {
  [...$('bars').children].forEach((el, i) => el.classList.toggle('dim', i >= n));
}

function updateConnectionUI() {
  const sub = $('subtitle');
  const badge = $('badge');
  const alertEl = $('alert');
  let cls = '', badgeCls = 'badge', text = '', alertMsg = '', rssi = '', bars = 0, sub2 = '';

  if (!state.bluetoothOn) {
    cls = 'off'; badgeCls += ' off'; text = 'Bluetooth is turned off';
    alertMsg = 'Bluetooth is off. Turn it on to send messages.'; rssi = 'OFF'; sub2 = 'Bluetooth off';
  } else if (!state.connectedDeviceId) {
    cls = 'warn'; badgeCls += ' warn'; text = 'Not connected • Tap the Bluetooth icon';
    alertMsg = 'No device linked. Tap Fix to connect.'; rssi = '--dBm'; sub2 = 'Disconnected';
  } else if (state.rangeLevel === 1) {
    text = 'Connected via Bluetooth • In range'; rssi = RANGE[1].rssi + 'dBm'; bars = 4; sub2 = 'Connected • Strong signal';
  } else if (state.rangeLevel === 2) {
    cls = 'warn'; badgeCls += ' warn'; text = 'Connected • Through wall';
    rssi = RANGE[2].rssi + 'dBm'; bars = 2; sub2 = 'Connected • Fair signal';
  } else {
    cls = 'off'; badgeCls += ' off'; text = 'Out of Bluetooth range (>30 m)';
    alertMsg = 'Out of range. Messages are queued and send when you are closer.'; rssi = RANGE[3].rssi + 'dBm'; sub2 = 'Signal lost';
  }

  sub.className = 'sub ' + cls;
  sub.textContent = text;
  badge.className = badgeCls;
  alertEl.hidden = !alertMsg;
  $('alertText').textContent = alertMsg;
  $('rssi').textContent = rssi;
  $('sub2').textContent = sub2;
  setBars(bars);
  $('distLabel').textContent = RANGE[state.rangeLevel].label;
  $('range').value = state.rangeLevel;

  if (isConnected()) deliverQueued();
}

function cycleSignal() {
  state.rangeLevel = (state.rangeLevel % 3) + 1;
  updateConnectionUI();
  toast('Simulated range: ' + RANGE[state.rangeLevel].label);
}
function setRange(v) {
  state.rangeLevel = parseInt(v, 10);
  updateConnectionUI();
}
function toggleBluetooth() {
  state.bluetoothOn = !state.bluetoothOn;
  $('radioSwitch').classList.toggle('off', !state.bluetoothOn);
  $('radioSub').textContent = state.bluetoothOn ? 'Visible • Discoverable' : 'Radio disabled';
  toast(state.bluetoothOn ? 'Bluetooth on' : 'Bluetooth off');
  updateConnectionUI();
  renderDevices();
}
function scanDevices() {
  if (!state.bluetoothOn) { toast('Turn on Bluetooth first'); return; }
  toast('Scanning…');
  setTimeout(() => toast('Found ' + state.devices.length + ' paired devices'), 800);
}
function connectDevice(id) {
  if (!state.bluetoothOn) toggleBluetooth();
  state.connectedDeviceId = id;
  if (state.rangeLevel === 3) state.rangeLevel = 1;
  const dev = state.devices.find((d) => d.id === id);
  updateConnectionUI();
  renderDevices();
  toast('Connected to ' + dev.name);
}
function disconnectDevice() {
  state.connectedDeviceId = null;
  updateConnectionUI();
  renderDevices();
  toast('Disconnected');
}
function renderDevices() {
  const box = $('devList');
  if (!state.bluetoothOn) {
    box.innerHTML = '<p class="muted" style="text-align:center;padding:14px 0">Turn on Bluetooth to see paired phones.</p>';
    return;
  }
  box.innerHTML = state.devices.map((d) => {
    const on = d.id === state.connectedDeviceId;
    return '<div class="dev' + (on ? ' on' : '') + '">' +
      '<div class="l"><div class="ic">📱</div><div style="min-width:0"><b>' + escapeHtml(d.name) + '</b><small>' + d.mac + ' • ' + d.rssi + ' dBm</small></div></div>' +
      (on ? '<button class="btn danger" onclick="disconnectDevice()">Disconnect</button>'
          : '<button class="btn" onclick="connectDevice(\'' + d.id + '\')">Connect</button>') +
      '</div>';
  }).join('');
}
function openBtModal() { renderDevices(); $('btModal').hidden = false; }
function closeBtModal() { $('btModal').hidden = true; }

/* ---------- get-the-app modal ---------- */
function repoInfo() {
  const h = location.hostname;
  if (!h.endsWith('.github.io')) return null;
  const user = h.split('.')[0];
  const first = location.pathname.split('/').filter(Boolean)[0];
  const repo = first && first !== 'index.html' ? first : h; // user-site repos are named <user>.github.io
  return { user, repo };
}
function setupAppLink() {
  const info = repoInfo();
  const link = $('apkLink');
  if (info) {
    link.href = 'https://github.com/' + info.user + '/' + info.repo + '/releases/latest/download/WorkmanChat.apk';
    $('apkHint').textContent = 'Not found yet? In your repository open Actions → "Build Android APK" and let it finish once.';
  } else {
    link.href = '#';
    link.addEventListener('click', (e) => { e.preventDefault(); toast('Deploy to GitHub first – see README'); });
    $('apkHint').textContent = 'This button points at your repository\'s latest APK once the page is hosted on GitHub Pages.';
  }
}
function openAppModal() { $('appModal').hidden = false; }
function closeAppModal() { $('appModal').hidden = true; }
async function installPwa() {
  if (!deferredInstall) { toast('Use your browser menu → Add to Home screen'); return; }
  deferredInstall.prompt();
  try { await deferredInstall.userChoice; } catch (e) { /* ignore */ }
  deferredInstall = null;
  $('installBtn').hidden = true;
  $('installBtn2').hidden = true;
}

/* ---------- messaging ---------- */
function handleInput() {
  const has = $('msgInput').value.trim().length > 0;
  $('icMic').hidden = has;
  $('icSend').hidden = !has;
}
function sendCurrent() {
  const input = $('msgInput');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  handleInput();
  $('emojiPicker').hidden = true;
  dispatchMessage(state.activeRole, text, 'text');
}
function sendPreset(text) { dispatchMessage(state.activeRole, text, 'text'); }
function sendBuzz() {
  dispatchMessage(state.activeRole, '🔔 ROOM PING! Check your phone', 'buzz');
  toast('Room ping sent');
}
function sendFrom2() {
  const input = $('msgInput2');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  dispatchMessage('peer', text, 'text');
}

function dispatchMessage(sender, text, type, duration) {
  const connected = isConnected();
  const msg = {
    id: Date.now() + Math.floor(Math.random() * 1000),
    sender, text, type: type || 'text', duration: duration || 0,
    time: fmtTime(),
    status: connected ? 'sent' : 'queued'
  };
  state.messages.push(msg);
  saveMessages();
  renderMessages();
  if (connected) progressDelivery(msg.id, sender === 'me', 0);
  else toast('Queued – will send when back in range');
}

function progressDelivery(id, canTriggerReply, offset) {
  setTimeout(() => updateStatus(id, 'delivered'), 350 + offset);
  setTimeout(() => {
    updateStatus(id, 'read');
    if (canTriggerReply && state.autoReply && !state.splitView) triggerAutoReply();
  }, 1100 + offset);
}

function updateStatus(id, status) {
  const m = state.messages.find((x) => x.id === id);
  if (m && m.status !== 'read') {
    m.status = status;
    saveMessages();
    renderMessages();
  }
}

function deliverQueued() {
  const q = state.messages.filter((m) => m.status === 'queued');
  if (!q.length) return;
  q.forEach((m, i) => {
    m.status = 'sent';
    progressDelivery(m.id, false, i * 150);
  });
  saveMessages();
  renderMessages();
  toast('Back in range – queued messages sent ✓✓');
}

function triggerAutoReply() {
  if (replying || !isConnected()) return;
  replying = true;
  $('typing').hidden = false;
  scrollToBottom();
  setTimeout(() => {
    $('typing').hidden = true;
    replying = false;
    if (!isConnected()) return;
    dispatchMessage('peer', PEER_REPLIES[Math.floor(Math.random() * PEER_REPLIES.length)], 'text');
  }, 1500);
}
function simulateIncoming() {
  if (!isConnected()) { toast('Connect Bluetooth first to receive messages'); return; }
  triggerAutoReply();
}
function toggleAutoReply() {
  state.autoReply = !state.autoReply;
  $('autoTag').textContent = state.autoReply ? 'ON' : 'OFF';
  saveSettings();
  toast('Auto-reply demo ' + (state.autoReply ? 'on' : 'off'));
}
function toggleRole() {
  state.activeRole = state.activeRole === 'me' ? 'peer' : 'me';
  $('roleTag').textContent = state.activeRole === 'me' ? 'Me' : 'Partner';
  $('msgInput').placeholder = state.activeRole === 'me' ? 'Message over Bluetooth…' : 'Typing as partner…';
  toast('Typing as ' + (state.activeRole === 'me' ? 'me' : 'partner'));
}
function toggleSplit() {
  state.splitView = !state.splitView;
  $('phone2').hidden = !state.splitView;
  $('splitTag').textContent = state.splitView ? 'ON' : 'OFF';
  renderMessages();
}
function clearChat() {
  if (!confirm('Clear this chat?')) return;
  state.messages = [];
  saveMessages();
  renderMessages();
  toast('Chat cleared');
}

/* ---------- emoji & voice (voice is demo only) ---------- */
function buildEmoji() {
  const box = $('emojiPicker');
  box.innerHTML = '';
  EMOJI.forEach((e) => {
    const b = document.createElement('button');
    b.textContent = e;
    b.addEventListener('click', () => insertEmoji(e));
    box.appendChild(b);
  });
}
function toggleEmoji() { $('emojiPicker').hidden = !$('emojiPicker').hidden; }
function insertEmoji(e) {
  const input = $('msgInput');
  input.value += e;
  input.focus();
  handleInput();
}
function startRecording() {
  voiceSeconds = 0;
  $('recTimer').textContent = '0:00';
  $('inputBar').hidden = true;
  $('recBar').hidden = false;
  clearInterval(voiceTimer);
  voiceTimer = setInterval(() => {
    voiceSeconds++;
    $('recTimer').textContent = Math.floor(voiceSeconds / 60) + ':' + String(voiceSeconds % 60).padStart(2, '0');
  }, 1000);
}
function cancelRecording() {
  clearInterval(voiceTimer);
  $('recBar').hidden = true;
  $('inputBar').hidden = false;
}
function finishRecording() {
  clearInterval(voiceTimer);
  const dur = Math.max(1, voiceSeconds);
  $('recBar').hidden = true;
  $('inputBar').hidden = false;
  dispatchMessage(state.activeRole, 'Voice message (' + dur + 's)', 'voice', dur);
}
function playVoice(btn) {
  const icon = btn.querySelector('span');
  if (icon.textContent === '▶') {
    icon.textContent = '⏸';
    toast('Voice notes are a demo-only feature');
    setTimeout(() => { icon.textContent = '▶'; }, 2000);
  } else {
    icon.textContent = '▶';
  }
}

/* ---------- rendering ---------- */
function tickSvg(status) {
  if (status === 'queued') return '<span title="Queued" style="font-size:11px">🕒</span>';
  if (status === 'sent') {
    return '<svg class="tick" viewBox="0 0 24 24"><path d="M6 13l4 4L20 7"/></svg>';
  }
  return '<svg class="tick' + (status === 'read' ? ' read' : '') + '" viewBox="0 0 24 24"><path d="M2 13l4 4L15 7M9 13l4 4L22 7"/></svg>';
}

function bubbleHtml(m, viewer) {
  const out = m.sender === viewer;
  let body;
  if (m.type === 'voice') {
    const secs = m.duration || 3;
    let wave = '';
    for (let i = 0; i < 18; i++) wave += '<i style="height:' + (6 + ((i * 7) % 12)) + 'px"></i>';
    body = '<div class="voice"><button class="play" onclick="playVoice(this)"><span>▶</span></button>' +
           '<div><div class="wave">' + wave + '</div><small>0:' + String(secs).padStart(2, '0') + '</small></div></div>';
  } else {
    body = '<div class="txt">' + escapeHtml(m.text) + '</div>';
  }
  return '<div class="row ' + (out ? 'out' : 'in') + '"><div class="bubble ' + (out ? 'out' : 'in') + (m.type === 'buzz' ? ' buzz' : '') + '">' +
    body + '<div class="meta"><span>' + escapeHtml(m.time) + '</span>' + (out ? tickSvg(m.status) : '') + '</div></div></div>';
}

function renderMessages() {
  $('messages').innerHTML = state.messages.map((m) => bubbleHtml(m, 'me')).join('');
  $('messages2').innerHTML = state.messages.map((m) => bubbleHtml(m, 'peer')).join('');
  scrollToBottom();
}
